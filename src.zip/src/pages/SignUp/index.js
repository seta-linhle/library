import React, { Component } from 'react';
import Signup from '../../components/SignUp';

class index extends Component {
  render() {
    return (
      <Signup />
    );
  }
}

export default index;