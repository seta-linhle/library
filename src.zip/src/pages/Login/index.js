import React, { Component } from 'react';
import Login from '../../components/Login';

class index extends Component {
  render() {
    return (
      <Login />
    );
  }
}

export default index;